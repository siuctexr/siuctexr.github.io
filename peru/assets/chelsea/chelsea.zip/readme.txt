All fonts are free for personal and commercial use (and I intend to keep it like this).

Nonetheless, if you consider a donation, it is always welcome. 

Is not mandatory, but it helps me getting caffeine so that I can keep on staying up at night to bring you more free stuff. 

http://antoniorodriguesjr.com/fonts.html

https://www.behance.net/ARJr
